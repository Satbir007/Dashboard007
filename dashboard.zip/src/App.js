import React from "react";
import Root from "./component/Root";

const App = () => {
  return <Root />;
};
export default App;
