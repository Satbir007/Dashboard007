import React from "react";
import { Container } from "react-bootstrap";

const DisplayInfoOne = (props) => {
  return (
    <Container fluid className="text-white pb-2">
      <span className={props.styleNumber}>{props.number}</span>
      <br />
      <span className={props.styleText}>{props.text}</span>
    </Container>
  );
};

export default DisplayInfoOne;
