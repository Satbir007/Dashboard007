import React from "react";
import { Col, Row } from "react-bootstrap";
import CompletedTrips from "./CompletedTrips";
import LateDispatchTrips from "./LateDispatchTrips";
import TotalCases from "./TotalCases";
import TotalTrips from "./TotalTrips";
import "../../css/main.css";

const RowTwo = () => {
  return (
    <Row className="bg-dark mx-2 my-3">
      <Col className="borderRight">
        <TotalCases />
      </Col>
      <Col className="borderRight">
        <CompletedTrips />
      </Col>
      <Col className="borderRight">
        <TotalTrips />
      </Col>
      <Col className="bg-danger">
        <LateDispatchTrips />
      </Col>
    </Row>
  );
};

export default RowTwo;
