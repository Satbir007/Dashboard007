import React from "react";
import { Col, Row } from "react-bootstrap";
import Home from "./Home";
import Options from "./Options";

const RowOne = () => {
  return (
    <Row>
      <Col>
        <Home />
      </Col>
      <Col sm="7">
        <Options />
      </Col>
    </Row>
  );
};

export default RowOne;
