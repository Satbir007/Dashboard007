import React from "react";
import { Container } from "react-bootstrap";

const Home = () => {
  return (
    <Container fluid>
      <h4 className="text-light mt-2"> Home</h4>
    </Container>
  );
};

export default Home;
