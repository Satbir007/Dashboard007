import React from "react";
import DisplayInfoTwo from "../UI/DisplayInfoTwo";

const PickTime = () => {
  const number = "12:45pm";
  const text = "PROJECT PICK END TIME";
  return <DisplayInfoTwo number={number} text={text} />;
};

export default PickTime;
