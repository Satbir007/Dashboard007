import React from "react";
import Buffer from "./Buffer";
import Service from "./Service";
import Sorter from "./Sorter";
import Outbound from "./Outbound";
import { Col, Row } from "react-bootstrap";

const RowFive = () => {
  return (
    <Row className=" mt-3 mx-2 text-white ">
      <Col className=" bg-dark p-3">
        <Buffer />
      </Col>
      <Col>
        <Service />
      </Col>
      <Col>
        <Row className="bg-dark px-2 pt-2 pb-4">
          <Sorter />
        </Row>
        <Row className="bg-dark px-2 pt-2 pb-4 mt-3">
          <Outbound />
        </Row>
      </Col>
    </Row>
  );
};

export default RowFive;
